package tictactoe;

public interface ReadonlyTicTacToeModel {

  /**
   * Get the current turn, i.e., the player who will mark on the next call to
   * move().
   *
   * @return the {@link Player} whose turn it is
   */
  Player getTurn();

  /**
   * Return the winner of the game, or {@code null} if there is no winner. If the
   * game is not over, returns {@code null}.
   *
   * @return the winner, or null if there is no winner
   */
  Player getWinner();

}
