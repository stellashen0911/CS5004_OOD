package tictactoe;

import java.io.PrintStream;

/**
 * Represents a view of the single game of TicTacToe. 
 * Three in a row down/across/diagonally to win; X goes
 * first.
 */
public class TicTacToeTextView implements TicTacToeView{
  private Appendable out;


  public TicTacToeTextView(Appendable out) {
    this.out = out;
  }
  
  @Override
  public Appendable getOut() {
    return this.out;
  }
  
  @Override
  public void showState(ReadonlyTicTacToeModel m) {
    ((PrintStream) out).println("The current board is as followig:");
    ((PrintStream) out).println(m.toString());
  }

  @Override
  public void promptForMove(Player p) {
    ((PrintStream) out).println("Now is your turn: " + p.toString());
    ((PrintStream) out).println("choose a row and column to go, row[0,2] col[0,2]: ");
  }

  @Override
  public void showResult(Player p) {
    ((PrintStream) out).println("Congrats! " + p.toString() + " win this game!");
  }

  @Override
  public void showMessage(String msg) {
    ((PrintStream) out).println(msg);
  }
  
}
