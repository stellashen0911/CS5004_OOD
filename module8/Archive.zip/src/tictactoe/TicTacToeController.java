package tictactoe;

import java.io.IOException;

/**
 * Represents a Controller for TicTacToe: handle user moves by executing them
 * using the model; convey move outcomes to the user in some form.
 */
public interface TicTacToeController {

  /**
   * Execute a single game of TicTacToe given a TicTacToe Model. When the game
   * is over, the playGame method ends.
   *
   * @param m a non-null TicTacToe model
   * @param v a non-null TicTacToe view 
   */
  void playGame(TicTacToeModel m, TicTacToeView v);
}
