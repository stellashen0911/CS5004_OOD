package tictactoe;

import java.util.Scanner;

/**
 * Represents a Controller for TicTacToe: handle user moves by executing them
 * using the model; convey move outcomes to the user in some form.
 */
public class TicTacToeTextController implements TicTacToeController{

  private final Readable in;
  
  public TicTacToeTextController(Readable input) {
    this.in = input;
  }
  
  @Override
  public void playGame(TicTacToeModel m, TicTacToeView v) {
    boolean quit = false;
    while(!quit) {
      //check whether the game is still online
      if (m.isGameOver()) {
        quit = true;
        v.showResult(m.getWinner());
        break;
      }
      //show the current board of the model
      v.showState(m);
      //prompt the user to enter a option X or O at what row and col
      v.promptForMove(m.getTurn());
      //read the row and col from the input stream
      Scanner scan = new Scanner(this.in);
      if (!scan.hasNextInt()) {
        v.showMessage("Input row must be integer!");
        break;
      }
      if (scan.next().equals("q") || scan.next().equals("Q")) {
        v.showMessage("User inputs quit.");
        break;
      }
      int currRow = scan.nextInt();
      if (!scan.hasNextInt()) {
        v.showMessage("Input col must be integer!");
        break;
      }
      if (scan.next().equals("q") || scan.next().equals("Q")) {
        v.showMessage("User inputs quit.");
        break;
      }
      int currCol = scan.nextInt();
      //set the row and col as player, and now it change to another player
      m.move(currRow, currCol);
    }
  }

}
