package tictactoe;

/**
 * Represents a view of the single game of TicTacToe. 
 * Three in a row down/across/diagonally to win; X goes
 * first.
 */
public interface TicTacToeView {

  /**
   * Displays the state of the game to the user.
   * 
   * @param m the state to display
   */
  public void showState(ReadonlyTicTacToeModel m);

  /**
   * Prompts a specific player to make a move.
   * 
   * @param p the player who should make the move
   */
  public void promptForMove(Player p);

  /**
   * Show result of the move for a specific player.
   * 
   * @param p the player whose result should be shown
   */
  public void showResult(Player p);

  /**
   * Show a message to the user.
   * 
   * @param msg the message to show
   */
  public void showMessage(String msg);
  
  /**
   * Return the appendable element of the view.
   * 
   * @return appendable element
   */
  public Appendable getOut();
}
