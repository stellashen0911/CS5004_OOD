package tictactoe;

import java.io.InputStreamReader;

/**
 * Run a Tic Tac Toe game interactively on the console.
 */
public class Driver {
  /**
   * Run a Tic Tac Toe game interactively on the console.
   * 
   * @param args not used
   */
  public static void main(String[] args) {
    // create the model that we will use
    TicTacToeModel model = new TicTacToeModelImpl();
    // create the view that uses the console for output
    TicTacToeView view = new TicTacToeTextView(System.out);
    // create the controller that uses the the keyboard for input
    Readable input = new InputStreamReader(System.in);
    TicTacToeController controller = new TicTacToeTextController(input);
    // pass control to the controller
    controller.playGame(model, view);
  }
}
