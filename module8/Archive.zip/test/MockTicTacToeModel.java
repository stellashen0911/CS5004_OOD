

import tictactoe.Player;
import tictactoe.TicTacToeModel;

public class MockTicTacToeModel implements TicTacToeModel {
  
  private StringBuilder log;
  private int[][] example;
  private Player turn;
  
  public MockTicTacToeModel(StringBuilder log) {
    this.log = log;
    turn = Player.X;
    example = new int[3][3];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        example[i][j] = 0;
      }
    }
  }

  @Override
  public Player getTurn() {
    log.append("getting turn").append(System.lineSeparator());
    return Player.X;
  }

  @Override
  public Player getWinner() {
    if (this.isGameOver()) {
      log.append("Has Winner.");
    } else {
      log.append("No Winner.");
    }
    return turn;
  }

  @Override
  public void move(int r, int c) {
    if (r < 0 || r > 2 || c < 0 || c > 2) {
      log.append("Row or col out of bound!").append(System.lineSeparator());
    }
    if (example[r][c] != 0) {
      log.append("Row or col is Occupied!").append(System.lineSeparator());
    }
    if (turn == Player.X) {
      example[r][c] = 1;
    } else if (turn == Player.O) {
      example[r][c] = 2;
    }
    turn = turn == Player.X ? Player.O : Player.X;
    log.append("Move row: %d, col: %d", r, c).append(System.lineSeparator());
  }

  @Override
  public boolean isGameOver() {
    boolean end = true;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (example[i][j] == 0) {
          end = false;
        }
      }
    }
    return end;
  }

  @Override
  public Player getMarkAt(int r, int c) {
    if (example[r][c] == 1) {
      return Player.X;
    } else if (example[r][c] == 2) {
      return Player.O;
    } 
    return null;
  }
  
  @Override
  public String toString() {
    if (log.length() == 0) {
      return "MODEL12345";
    }
    return log.toString();
  }
}
