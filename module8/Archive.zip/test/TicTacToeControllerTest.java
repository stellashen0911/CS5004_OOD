import static org.junit.Assert.assertEquals;

import java.io.StringReader;
import org.junit.Test;
import tictactoe.TicTacToeController;
import tictactoe.TicTacToeModel;
import tictactoe.TicTacToeModelImpl;
import tictactoe.TicTacToeTextController;
import tictactoe.TicTacToeTextView;
import tictactoe.TicTacToeView;

/**
 * Test cases for the TicTacToe controller, using mocks for readable and
 * appendable.
 */
public class TicTacToeControllerTest {

  /** Test with a failing appendable. */
  @Test(expected = IllegalStateException.class)
  public void testFailingAppendable() {
    TicTacToeModel m = new TicTacToeModelImpl();
    StringReader input = new StringReader("2 2 1 1 3 3 1 2 1 3 2 3 2 1 3 1 3 2");
    Appendable gameLog = new FailingAppendable();
    TicTacToeView v = new TicTacToeTextView(gameLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
  }

  /** Testing quitting*/
  @Test
  public void testQuitWithoutMove() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("q");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    // check the log from the model is as expected
    String expectedModel = "MODEL12345"; 
    assertEquals(expectedModel, modelLog.toString());
    // check the output of the view is as expected
    String expectedView = "User inputs quit.";
    assertEquals(expectedView, viewLog.toString());
  }
  
  /** Testing Input where the q comes instead of an integer for the row */
  @Test
  public void testQuitForRow() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("q 2");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    String expectedModel = "MODEL12345"; 
    assertEquals(expectedModel, modelLog.toString());
    String expectedView = "User inputs quit.";
    assertEquals(expectedView, viewLog.toString());
  }
  
  /** Testing Input where the q comes instead of an integer for the column */
  @Test
  public void testQuitForCol() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("2 q");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "MODEL12345"; 
    assertEquals(expectedModel, modelLog.toString());
    String expectedView = "User inputs quit.";
    assertEquals(expectedView, viewLog.toString());
  }

  /** Testing where non-integer garbage comes instead of an integer for the row */
  @Test
  public void testGarbageForRow() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("werwwr 2");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "MODEL12345"; 
    assertEquals(expectedModel, modelLog.toString());
    String expectedView = "Input row must be integer!";
    assertEquals(expectedView, viewLog.toString());
  }
  
  /** Testing where non-integer garbage comes instead of an integer for the column */
  @Test
  public void testGarbageForCol() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("2 werwwr");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "MODEL12345"; 
    assertEquals(expectedModel, modelLog.toString());
    String expectedView = "Input col must be integer!";
    assertEquals(expectedView, viewLog.toString());
  }
  
  /** Testing where the move is integers, but outside the bounds of the board */
  @Test
  public void testMoveOutOfBound() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("5 8");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "Row or col out of bound!"; 
    assertEquals(expectedModel + System.lineSeparator(), modelLog.toString());
  }
  
  /** Testing  where the move is integers, but invalid because the cell is occupied */
  @Test
  public void testMoveOcupied() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("5 8 5 8");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "Row or col is Occupied!"; 
    assertEquals(expectedModel + System.lineSeparator(), modelLog.toString());
  }
  
  /** Testing where the move is valid but there is no winner */
  @Test
  public void testMoveNoWinner() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("1 2 0 2");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "No Winner."; 
    assertEquals(expectedModel + System.lineSeparator(), modelLog.toString());
  }
  
  /** Testing where the move is valid but there is winner */
  @Test
  public void testMoveWithWinner() {
    StringBuilder modelLog = new StringBuilder();
    TicTacToeModel m = new MockTicTacToeModel(modelLog);
    StringReader input = new StringReader("1 2 0 2 1 1 0 1 1 0");
    StringBuilder viewLog = new StringBuilder();
    TicTacToeView v = new TicTacToeTextView(viewLog);
    TicTacToeController c = new TicTacToeTextController(input);
    c.playGame(m, v);
    //the module will not move
    String expectedModel = "Has Winner."; 
    assertEquals(expectedModel + System.lineSeparator(), modelLog.toString());
  }
  
}
